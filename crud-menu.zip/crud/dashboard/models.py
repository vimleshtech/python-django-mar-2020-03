# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

import mysql.connector as con 
# Create your models here.
import json 

def saveProdct(pname,price,qty):

        try:
            c = con.connect(host='localhost',database='hrms',user='root',password='root')
            cur = c.cursor()

            cur.execute("insert into products(pname,price,qty) values('{}',{},{})".format(pname,price,qty))
            c.commit()
        except:
            return "something went wrong!"
        return "Product is added"

def getProduct():
    
            c = con.connect(host='localhost',database='hrms',user='root',password='root')
            cur = c.cursor()

            cur.execute("select * from products")
            res = cur.fetchall()
            data = []
            for r in res:
                d={'pid':r[0],'pname':r[1],'price':r[2],'qty':r[3]}
                data.append(d)

            #return data 
            return json.dumps(data) 

def delProduct(pid):
    
            c = con.connect(host='localhost',database='hrms',user='root',password='root')
            cur = c.cursor()

            cur.execute("delete from products where pid="+pid)
            c.commit()

            #return data 
            return "Product is removed"

    


#test call 
#saveProdct('dove',100,33)
#o = getProduct()
#print(o)


