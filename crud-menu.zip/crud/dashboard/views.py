# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse

from . import models 
import json

import mysql.connector as c
# Create your views here.
def index(request):
    #return HttpResponse('<h1> hello this this is test web app </h1>')
    #return render(request,'dashboard/index.html')
    #return render(request,'dashboard/viewdata.html')
    #return render(request,'dashboard/product.html')
    return render(request,'dashboard/menu.html')

def getMenu(request):
    #db connection 
    con = c.connect(host='localhost',database='hrms',user='root',password='root')
    cur = con.cursor()
    
    mid = request.GET['id']
    res =""
    
    if len(mid)<1:
        cur.execute("select mid,name,path from menu where pid is null")
        data = cur.fetchall()
        
        for row in data:
            res +="<div class='mn' id='{}' onclick='getMenu(this.id,0)'>{} </div>".format(row[0],row[1])
            res +="<div style='margin: 0px;' id='subh_{}'> </div>".format(row[0])

        
    else:
        cur.execute("select mid,name,path from menu where pid="+str(mid))
        data = cur.fetchall()
        
        for row in data:
            res +="<p class='submn' id='{}' onclick='getMenu(this.id,1)'  >{} </p>".format(row[0],row[1])

    return HttpResponse(res)


def register(request):
    name = request.GET['name']
    email = request.GET['email']
    pwd = request.GET['pwd']
    age = request.GET['age']

    #db connection 
    con = c.connect(host='localhost',database='employee',user='root',password='root')
    cur = con.cursor()
    
    cur.execute("insert into user(name,email,pwd,age) values('{}','{}',{},{})".format(name,email,pwd,age))
    con.commit()
    print('data inserted')


    #read data from sql table
    cur.execute('select * from user')    
    data = cur.fetchall()
    out ='<div>'
    for row in data:
        out +='<p>'+str(row[0])+'|'+str(row[1])+'</p>'

    out +='<div>'
    #print(data)

    return HttpResponse(out)
  

def addProduct(request):
    pname = request.GET['pname']
    price = request.GET['price']
    qty = request.GET['qty']

    res= models.saveProdct(pname,price,qty)

    return HttpResponse(res)

def getProduct(request):
    res= models.getProduct()
    return HttpResponse(res)

def delProduct(request):
    pid = request.GET['pid']
    res = models.delProduct(pid)
    return HttpResponse(res)

