# -*- coding: utf-8 -*-
from __future__ import unicode_literals



from django.db import models

import mysql.connector as con 
# Create your models here.

def saveProdct(pname,price,qty):

    try:
        con.connect(host='local',database='hrms',user='root',password='root')
        cur = con.cursor()

        cur.execute("insert into products(pname,price,qty) values('{}',{},{})".format(pname,price,qty))
        con.commit()
    except:
        return "something went wrong!"
    return "Product is added"

    