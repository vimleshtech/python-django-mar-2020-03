
from django.conf.urls import url,include
from . import views


urlpatterns = [

    #url('delProduct', views.delProduct,name="delProduct"),
    #url('getProduct', views.getProduct,name="getProduct"),
    #url('addproduct', views.addProduct,name="addProduct"),
    #url('register', views.register,name="register"),
    url('getmenu',views.getMenu,name='getmenu'),
    url('', views.index,name="index"),
    
]
