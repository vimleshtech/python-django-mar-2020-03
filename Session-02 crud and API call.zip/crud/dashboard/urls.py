
from django.conf.urls import url,include
from . import views


urlpatterns = [

 
    url('addproduct', views.addProduct,name="addProduct"),
    url('register', views.register,name="register"),
    url('', views.index,name="index"),
    
]
