from models import Customer

cn ='nitin'
email='nitin@gmail.com'
cust = Customer(customer_name=cn,customer_email=email)
cust.save()

print('data is saved')
