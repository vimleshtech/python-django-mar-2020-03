
function test(){

    alert('hi');
}


function add(a,b){    
    alert(a+b);
}