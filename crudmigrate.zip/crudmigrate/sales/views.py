from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

from . import models

def index(request):
    return HttpResponse("index ... hello")


def new_customer(request):
    cn = request.GET['name']
    email = request.GET['email']
    cust = models.Customer(customer_name=cn,customer_email=email)
    cust.save()
    

    return HttpResponse("index ... hello")


def all_customer(request):
    return HttpResponse("index ... hello")

    

