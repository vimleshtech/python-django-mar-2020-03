# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse

from . import models 

import mysql.connector as c
# Create your views here.
def index(request):
    #return HttpResponse('<h1> hello this this is test web app </h1>')
    #return render(request,'dashboard/index.html')
    #return render(request,'dashboard/viewdata.html')
    return render(request,'dashboard/product.html')


def register(request):
    name = request.GET['name']
    email = request.GET['email']
    pwd = request.GET['pwd']
    age = request.GET['age']

    #db connection 
    con = c.connect(host='localhost',database='employee',user='root',password='root')
    cur = con.cursor()
    
    cur.execute("insert into user(name,email,pwd,age) values('{}','{}',{},{})".format(name,email,pwd,age))
    con.commit()
    print('data inserted')


    #read data from sql table
    cur.execute('select * from user')    
    data = cur.fetchall()
    out ='<div>'
    for row in data:
        out +='<p>'+str(row[0])+'|'+str(row[1])+'</p>'

    out +='<div>'
    #print(data)

    return HttpResponse(out)
  

def addProduct(request):
    pname = request.GET['pname']
    price = request.GET['price']
    qty = request.GET['qty']

    res= models.saveProdct(pname,price,qty)

    return HttpResponse(res)


