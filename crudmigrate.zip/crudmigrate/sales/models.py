from django.db import models

#entity or model driven development 
# Create your models here.

class Product(models.Model):
    #product_id = models.AutoField()
    product_name= models.CharField(max_length=50)
    product_category = (('S','Small'),('M','Medium'),('L','Large')) 
    product_price= models.FloatField()
    product_description= models.CharField(max_length=500)
    product_qty= models.IntegerField()
    product_exp = models.DateTimeField()

    
class Customer(models.Model):
    #product_id = models.AutoField()
    customer_name= models.CharField(max_length=50)
    customer_gender = (('M','Male'),('F','Female')) 
    customer_email= models.CharField(max_length=200)
    


